module Main where
import Modules.DayFour
import Modules.DayThree

main :: IO ()
main = do
    rund4
